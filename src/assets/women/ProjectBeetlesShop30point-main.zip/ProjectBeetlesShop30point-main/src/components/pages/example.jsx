const ordered = [
    //เก็บข้อมูลออเดอร์
    {
        id: 1,
        name: 'test', 
        //เก็บข้อมูล product
        cart: [
            {
                id: 1,
                name:'cake'
            },
            {
                id: 2,
                name:'donut'
            },
        ]
    },
    {
        id: 2,
        name: 'test2',
        cart: [
            {
                id: 1,
                name:'cake'
            },
            {
                id: 2,
                name:'donut'
            },
        ]
    }
]